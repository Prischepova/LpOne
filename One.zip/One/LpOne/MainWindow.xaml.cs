﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LpOne
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnSignIn_Click(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
            login.Owner = this;
            login.Show();
        }

        private void BtnInfoKorpuses_Click(object sender, RoutedEventArgs e)
        {
            InfoKorpuses infoKorpuses = new InfoKorpuses();
            infoKorpuses.Show();
        }

        private void BtnSignOut_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ComboBox_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {

        }

        private void BtnChoose_Click(object sender, RoutedEventArgs e)
        {
            if (Korpus1.Content != Korpus2.Content)
            {
                KorpusOne korpusOne = new KorpusOne();
                korpusOne.Show();
            }
        }
    }
}
